"""GeoDistill-RT research prototype."""
